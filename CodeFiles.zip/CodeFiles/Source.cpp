#include <SFML/Graphics.hpp>
#include <ctime>
#include <iostream>
using namespace std;
#include"start.h"

int main() {
    MainMenu mainMenu;
    mainMenu.run();
    return 0;
}